I make 4 versions of the Mondrian Arts. PLEASE CHECK ALL OF THEM OUT!!
In the MondrianExtended.kt file, you have to click your mouse in the screen to see the change in color. The color of the artwork depend on the position where you click the mouse.

The ModrianExtended2.kt file draws the artwork rectangle by rectangle, while the Animated version display the drawing of the MondrianArts. There are 2 versions of the animated one, one displays the drawing of the rectangle, the other displays the drawing in a recursive way.
