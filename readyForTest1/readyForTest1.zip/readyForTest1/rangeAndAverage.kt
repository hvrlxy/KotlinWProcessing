import kotlin.math.*

fun main (args:Array<String>){
	var size = args.size
	val intergerArray = IntArray(size) {0}
	for (i in 0 until size){
		intergerArray[i] = args[i].toInt()
	}
	var max = 0

	for (i in 0 until size){
		if (intergerArray[i] > max){
			max = intergerArray[i]
		}
	}

	var min = intergerArray[0]

	for (i in 1 until size){
		if (intergerArray[i] < min){
			min = intergerArray[i]
		}
	}

	var sum = 0


	for (i in 0 until size){
		sum = sum + intergerArray[i]
	}

	var average = sum.toDouble()/size

	println("range = $min..$max")
	println("average = $average")
}