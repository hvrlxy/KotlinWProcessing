/**********************************************************************
 *  readme template
 *  N-Body Simulation
 **********************************************************************/

Name: Ha Le

Hours to complete assignment (optional): 10 hours

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I had problem with gradle installation, so I have to compile the project using processing compiler.

/**********************************************************************
 *  If you created your own universe for extra credit, describe it
 *  here and tell us why it is interesting.  Be sure to include all
 *  necessary files and tell us how to load your universe.
 **********************************************************************/


/**********************************************************************
 *  List whatever help (if any) that you received. You don't need to
 *  include the course materials or lectures, but do include any
 *  additional help your received from people (course staff, lab TAs,
 *  classmates) and include their names.
 **********************************************************************/
Professor San Skulrattanakulchai
Filip Belik

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

