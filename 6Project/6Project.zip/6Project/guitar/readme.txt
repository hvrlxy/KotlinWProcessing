/***********************************************************************
 *  Name:    Ha Le
 **********************************************************************/

Programming Assignment: Guitar Hero

Hours to complete assignment (optional):



/**********************************************************************
 *  Did you receive help from classmates, past MCS 178 students, or
 *  anyone else? If so, please list their names.
 **********************************************************************/

Yes or no? NO



/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Yes or no? NO



/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

I used the processing compiler to finish the project. Come see me if you cannot play the extra credit!
To run the extra credit through the processing compiler, type:
processing-kt GuitarHeroExtraKt < music/filename

I made several songs, from simple to complicated ones. The longest one is more than 1 minute long. I hope you will enjoy that! 

You can change the tempo of the song through the command line. Just put the number after the filename. 0.5 is slow, while 2 is fast.
